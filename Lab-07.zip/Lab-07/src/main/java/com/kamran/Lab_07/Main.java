package com.kamran.Lab_07;

public class Main {

	public static void main(String[] args) {
		//ArrayList<Employee> newEmployee = new ArrayList<Employee>();
		
		Person p1 = new Person();
		p1.setId(1);
		p1.setname("Uqqasha");
		p1.setFather_name("Ijaz");
		p1.setOrganization("NUST");
		p1.setMobile("0301-8703521");
		
		/*Employee e2 = new Employee();
		e2.setId(2);
		e2.setFirst_name("Abdulrahim");
		e2.setLast_name("Sabir");
		e2.setSalary(54321);*/
		
		PersonFactory per = new PersonFactory();
		per.save(p1);
		per.print();
		
		per.closeSession();
		
		
	}
}

